<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Email; 
use Log;

class LoginController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $url = url('/input');
        $title="Login";
        $email=new Email;
        $data=compact('title','url','email');
        return view('form')->with($data);
    }
    public function input($email)
    {
        $url = url('/input');
        $title="Enter value";
        $email = Email::where('email',$email);
        $data=compact('title','url','email');
        return view('input')->with($data);
    }
    public function mail(Request $request)
    {
        Log::info($request);
        Email::where('customer_id',$id)->update([
        ]);
        return redirect('/input');
    }
    public function email_validate($data){
        Log::info("inside email_validate");
        $value = Email::where('email', $data->email)->count();
        if($value == 0){
            return response()->json(true);
        }else{
            return response()->json(false);
        }
    }
}