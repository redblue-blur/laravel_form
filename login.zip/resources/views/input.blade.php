<x-header title="{{$title}}"/>
  <body>
        <h1>{{$title}}</h1>
        <form action="{{$url}}" method="">
            <div class="container pad">
                <div class="form-group">
                    <label for="">Enter comment for {{$email->email}}</label>
                    <input type="text" class="form-control" name="comment" id="" aria-describedby="" value="">
                    <span class="text-danger">
                        <!-- @error('name')
                            {{$message}}
                        @enderror -->
                    </span>
                    </br>
                    <button class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
<x-footer/>